public class Main {
    public static void main(String[] args){


        MountainBike b1 = new MountainBike(23,"violeta",4,2);
        Playera b2 = new Playera(23,"Azul",true,false);
        b1.imprimirAtributos();
        b2.imprimirAtributos();

    }
}
