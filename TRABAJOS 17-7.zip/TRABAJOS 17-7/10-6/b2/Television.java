public class Television{
    private String marca;
    private double precio;
    private double inches;


    public void setMarca(String marcax){
        marca = marcax;
    }
    public void setPrecio(double preciox){
        precio = preciox;
    }
    public void setInches(double inchesx){
        inches = inchesx;
    }
}