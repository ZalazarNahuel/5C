public class Silla{
    private String marca;
    private double largo;
    private double precio;

    public void setMarca(String marcax){
        marca = marcax;
    }
    public void setLargo(double largox){
        largo = largox;
    }
    public void setPrecio(double preciox){
        precio = preciox;
    }
}