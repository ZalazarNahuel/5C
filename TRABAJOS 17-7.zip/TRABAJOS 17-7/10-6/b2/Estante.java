public class Estante{
    private String material;
    private float grosor;
    private String color;

    public void setMaterial(String materialx){
        material = materialx;
    }
    public void setGrosor(float grosorx){
        grosor = grosorx;
    }
    public void setColor(String colorx){
        color = colorx;
    }
}