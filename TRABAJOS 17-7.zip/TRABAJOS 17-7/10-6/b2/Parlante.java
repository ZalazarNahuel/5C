public class Parlante{
    private String marca;
    private float sonido;
    private boolean bluetooth;

    public void setMarca(String marcax){
        this.marca = marcax;
    }
    public void setSonido(float sonidox){
        this.sonido = sonidox;
    }
    public void setBluetooth(boolean bluetoothx){
        this.bluetooth = bluetoothx;
    }
}