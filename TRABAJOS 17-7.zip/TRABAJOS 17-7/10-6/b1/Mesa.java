public class Mesa extends Elemento {

    public Mesa(double pesox, String colorx, String materialx){
        super(pesox,colorx,materialx);
    }
}
