public class Ventana extends Elemento {

    public Ventana(double pesox, String colorx, String materialx){
        super(pesox,colorx,materialx);
    }
}
