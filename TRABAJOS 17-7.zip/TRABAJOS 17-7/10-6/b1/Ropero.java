public class Ropero extends Elemento {

    public Ropero(double pesox, String colorx, String materialx){
        super(pesox,colorx,materialx);
    }
}
