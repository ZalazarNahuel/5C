public class Cama extends Elemento{
    public Cama(double pesox, String colorx, String materialx){
        super(pesox,colorx,materialx);
    }
}
