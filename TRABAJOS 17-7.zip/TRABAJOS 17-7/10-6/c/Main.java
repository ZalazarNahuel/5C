public class Main{
    public static void main(String[] args) {
        Brujo carbo = new Brujo("carbone", 50, 10, 1);
        Guerrero nawe = new Guerrero("Nahuel", 150, 800, 5);
        carbo.mostrarMago();
        nawe.mostarGuerrero();    
    }
}