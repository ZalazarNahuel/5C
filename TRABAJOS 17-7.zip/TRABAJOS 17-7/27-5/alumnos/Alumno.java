public class Alumno{
    private int edad;

    public Alumno(int edadx){
        edad=edadx;
    }

    public int getEdad(){
        return this.edad;
    }
}