public class Observacion {

    private String resultado;


    public Observacion(){
        resultado="";
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getResultado(){
        return this.resultado;
    }
}
